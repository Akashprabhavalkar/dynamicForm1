import { Component, OnInit, VERSION } from '@angular/core';
import { data } from 'jquery';
import * as XLSX from 'xlsx';
import { CsvService } from '../csv.service';
@Component({
  selector: 'app-features',
  templateUrl: './features.component.html',
  styleUrls: ['./features.component.css']
})
export class FeaturesComponent implements OnInit {
  // title = 'excel to json';
  // convertedJson!:string

  // fileUpload(event: any) {
  //   console.log(event.target.files);
  //   const selectedFile = event.target.files[0];
  //   const fileReader = new FileReader();
  //   fileReader.readAsBinaryString(selectedFile);
  //   fileReader.onload = (event: any) => {
  //     console.log(event);
  //     let binaryData = event.target.result;
  //     let workbook = XLSX.read(binaryData, { type: 'binary' });
  //     workbook.SheetNames.forEach(sheet => {
  //       const data = XLSX.utils.sheet_to_json(workbook.Sheets[sheet]);
  //       console.log(data);
  //       this.convertedJson = JSON.stringify(data,undefined,4);
  //     })
  //     console.log(workbook)
  //   }

  // }
  // name = "Angular " + VERSION.major;
  // convertedObj: any = "";
  // convert(objArray: any) {
  //   console.log(objArray);
  //   this.convertedObj = JSON.stringify(objArray, null, 2);
  // }
  // onError(err: any) {
  //   this.convertedObj = err
  //   console.log(err);
  // }

  // constructor(private csv: CsvService) { }

  // jsonData = [
  //   {
  //     name: "Anil Singh",
  //     age: 33,
  //     average: 98,
  //     approved: true,
  //     description: "I am active blogger and Author."
  //   },
  //   {
  //     name: 'Reena Singh',
  //     age: 28,
  //     average: 99,
  //     approved: true,
  //     description: "I am active HR."
  //   },
  //   {
  //     name: 'Aradhya',
  //     age: 4,
  //     average: 99,
  //     approved: true,
  //     description: "I am engle."
  //   },
  // ];

  // download() {
  //   this.csv.downloadFile(this.jsonData, 'jsontocsv');
  // }

  // willDownload=false;
  name = "Angular " + VERSION.major;
  convertedObj:any = "";
  convert(objArray:any) {
    console.log(objArray);
    this.convertedObj = JSON.stringify(objArray, null, 2);
    this.setDownload(this.convertedObj);
  }
  onError(err:any) {
    this.convertedObj = err
    console.log(err);
  }

  setDownload(data:any) {
    // this.willDownload = true;
    setTimeout(() => {
      const el =<HTMLElement>document.querySelector("#download");
      el.setAttribute("href", `data:text/json;charset=utf-8,${encodeURIComponent(data)}`);
      el.setAttribute("download", 'csvtojson.json');
    }, 1000)
  }
  ngOnInit(): void {
  }

}
